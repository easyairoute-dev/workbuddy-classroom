#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""把 Obsidian 事务列表同步到「律智驾舱」工作台的在线表。

只同步索引：事务（事务.md 的 YAML）与材料（材料卡.md 的 YAML），原件留在 Obsidian。
幂等：同一「库标识＋Obsidian 事务ID」复用原记录；材料按「事务ID＋材料ID」去重；
已存在的事务不改人工填写的字段，已存在的材料不改（因此工作台里手改的「档案栏目」不会被覆盖）。

用法（Windows 推荐 py -3 -X utf8）：
    py -3 -X utf8 scripts/sync_workbench.py --vault "库根目录"
    py -3 -X utf8 scripts/sync_workbench.py --vault "..." --only "青禾设备采购"
    py -3 -X utf8 scripts/sync_workbench.py --vault "..." --dry-run
    py -3 -X utf8 scripts/sync_workbench.py --vault "..." --json out.json

退出码：0 = 全部同步成功；1 = 有写入失败（对应「已归档，待同步」，直接重跑即可只补缺失）。
"""
from __future__ import annotations

import argparse
import atexit
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime
from pathlib import Path

import yaml

DEFAULT_VAULT = str(Path.home() / "Documents" / "Obsidian Vault")
DEFAULT_LIBRARY = ""

# 工作台「律智驾舱」绑定的三张表（12 张绑定表中的事务、文档与证据、配置与规则）
MATTERS_DB = ""
DOCS_DB = ""
CFG_DB = ""

CFG_CAT = "来源映射"
CFG_META = "__meta__"
SECTIONS = ("文档与证据", "沟通记录", "费用台账", "结案归档与沉淀")
MARK_RE = re.compile(r"〔材料ID ([0-9a-f]{64}) ｜ 栏目 ([^｜〕]*) ｜ 提交 ([^〕]*)〕")
SUBMIT_RE = re.compile(r"〔提交 ([^〕]*)〕")


# ---------------------------------------------------------------- 在线表读写
def library_dir() -> Path:
    for cand in (os.environ.get("CODEBUDDY_SKILL_DIR"), DEFAULT_LIBRARY):
        if cand and (Path(cand) / "database" / "query_database_record.py").exists():
            return Path(cand)
    raise SystemExit(
        "找不到资料库脚本目录。请设置环境变量 CODEBUDDY_SKILL_DIR 指向资料库技能目录"
        "（内含 database/query_database_record.py），或用 --library 指定。"
    )


def db(script: str, payload: dict) -> dict:
    """调用资料库技能的 CLI（JSON stdin/stdout）。"""
    path = library_dir() / "database" / script
    proc = subprocess.run(
        [sys.executable, str(path), "--stdin"],
        input=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        capture_output=True,
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    raw = proc.stdout.decode("utf-8", "replace").strip()
    i = raw.find("{")
    if i < 0:
        return {"error": raw or proc.stderr.decode("utf-8", "replace") or "空响应"}
    return json.loads(raw[i:])


def query_all(database_id: str) -> list[dict]:
    rows, cursor = [], ""
    while True:
        payload = {"database_id": database_id, "page_size": 100}
        if cursor:
            payload["start_cursor"] = cursor
        d = db("query_database_record.py", payload)
        if d.get("error"):
            raise RuntimeError("读取 %s 失败：%s" % (database_id, d["error"]))
        rows.extend(d.get("results") or [])
        cursor = d.get("next_cursor") or ""
        if not d.get("has_more") or not cursor:
            return rows


def add_records(database_id: str, records: list[dict]) -> list[str]:
    """批量新增，返回与 records 等长的记录 ID 列表（失败位置为 ''）。"""
    ids = [""] * len(records)
    for start in range(0, len(records), 50):
        chunk = records[start:start + 50]
        d = db("batch_add_database_records.py", {"database_id": database_id, "records": chunk})
        if d.get("error"):
            raise RuntimeError("写入失败：%s" % d["error"])
        for item in d.get("results") or []:
            idx = start + int(item.get("index", 0))
            if item.get("success") and item.get("id"):
                ids[idx] = item["id"]
    return ids


def update_records(database_id: str, updates: list[dict]) -> None:
    for start in range(0, len(updates), 50):
        d = db("batch_update_database_records.py", {"database_id": database_id, "records": updates[start:start + 50]})
        if d.get("error"):
            raise RuntimeError("更新失败：%s" % d["error"])


# ---------------------------------------------------------------- 并发锁
def lock_path(vault: Path) -> Path:
    """同一库共用一把锁，锁放在临时目录，不污染 Obsidian 库。"""
    tag = hashlib.sha1(str(vault.resolve()).lower().encode("utf-8")).hexdigest()[:12]
    folder = Path(tempfile.gettempdir()) / "lawyer-wb-sync"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / ("%s.lock" % tag)


def acquire_lock(vault: Path, timeout: int) -> tuple[Path | None, bool]:
    """拿到锁返回 (路径, 是否等待过)；超时返回 (None, ...)。

    归档流程与本脚本共用同一把锁：若正好在归档，本脚本先等它结束再补扫，
    避免同一事务被两个进程同时写入。
    """
    path = lock_path(vault)
    deadline = time.time() + max(0, timeout)
    waited = False
    while True:
        try:
            fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, ("%d %s" % (os.getpid(), datetime.now().isoformat(timespec="seconds"))).encode())
            os.close(fd)
            return path, waited
        except FileExistsError:
            try:
                age = time.time() - path.stat().st_mtime
            except FileNotFoundError:
                continue
            if age > 1800:  # 上次异常退出留下的僵尸锁
                try:
                    path.unlink()
                except FileNotFoundError:
                    pass
                continue
            if time.time() >= deadline:
                return None, waited
            waited = True
            time.sleep(5)


# ---------------------------------------------------------------- 待归档扫描
def scan_pending(vault: Path, only: str = "") -> list[dict]:
    """找出「只有原件、缺索引」的项目与材料目录，供人工补归档。"""
    root = vault / "事务列表"
    items: list[dict] = []

    def rel(p: Path) -> str:
        return p.relative_to(vault).as_posix()

    for proj in sorted(p for p in root.iterdir() if p.is_dir()):
        if only and only not in proj.name:
            continue
        note = proj / "事务.md"
        if not note.exists():
            files = [f for f in proj.rglob("*") if f.is_file() and not f.name.startswith(".")]
            if files:
                items.append({"类型": "缺事务索引（事务.md）", "位置": rel(proj),
                              "文件数": len(files), "文件": [rel(f) for f in files][:20]})
            continue
        meta = front_matter(note)
        if not text_of(meta.get("事务ID")) or not text_of(meta.get("事务名称")):
            items.append({"类型": "事务.md 缺事务ID或事务名称", "位置": rel(note),
                          "文件数": 1, "文件": [rel(note)]})
        mat_root = proj / "文档与证据"
        if not mat_root.is_dir():
            continue
        for sub in sorted(p for p in mat_root.iterdir() if p.is_dir()):
            if (sub / "材料卡.md").exists():
                continue
            files = [f for f in sub.rglob("*") if f.is_file()]
            if files:
                items.append({"类型": "缺材料卡（材料卡.md）", "位置": rel(sub),
                              "文件数": len(files), "文件": [rel(f) for f in files][:20]})
        loose = [f for f in mat_root.iterdir() if f.is_file() and not f.name.startswith(".")]
        if loose:
            items.append({"类型": "材料未建目录（直接放在 文档与证据 下）", "位置": rel(mat_root),
                          "文件数": len(loose), "文件": [rel(f) for f in loose][:20]})
    return items



def front_matter(path: Path) -> dict:
    text = path.read_text("utf-8-sig", errors="replace")
    if not text.startswith("---"):
        return {}
    end = text.find("\n---", 3)
    if end < 0:
        return {}
    data = yaml.safe_load(text[3:end]) or {}
    return data if isinstance(data, dict) else {}


def text_of(value) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return "、".join(str(x) for x in value if x is not None)
    return str(value).strip()


def submit_state(value) -> str:
    """统一成 已提交 / 未提交 / 待确认。"""
    if value is True:
        return "已提交"
    if value is False:
        return "未提交"
    s = text_of(value)
    if s in ("已提交", "是", "true", "True", "提交"):
        return "已提交"
    if s in ("未提交", "否", "false", "False"):
        return "未提交"
    return "待确认"


def infer_section(value: str) -> str:
    """与工作台页面 inferSection 同一套判断顺序。"""
    v = value or ""
    if not v:
        return ""
    if re.search(r"结案(?:报告|小结|总结|复盘|归档表)|案件复盘|结案归档", v):
        return "结案归档与沉淀"
    if re.search(r"邮件|电邮|聊天(?:记录|截图)|微信(?:记录|截图)|通话(?:记录|录音)|电话(?:沟通|记录|录音)|"
                 r"沟通(?:记录|纪要|函)|接谈(?:记录|笔录|纪要)|首次接谈|会谈(?:记录|纪要)|会议(?:记录|纪要)|"
                 r"访谈(?:记录|纪要)|谈话笔录|往来函件|^函件拟稿$", v):
        return "沟通记录"
    # 交货、回款、货款、对账属于案件证据，不因「款」字进费用台账
    if re.search(r"交货|回款|货款|结算明细|对账单|对账|付款计划|欠款", v):
        return "文档与证据"
    if re.search(r"发票|收据|报销(?:单|凭证|明细)|费用(?:单|凭证|台账|清单|明细)|缴费(?:单|凭证|通知)|"
                 r"收费凭证|付款凭证|支付凭证|转账(?:凭证|回单)|银行回单", v):
        return "费用台账"
    if re.search(r"合同|协议|委托单|送货单|证据目录|核验工作底稿|工资差额核对表", v):
        return "文档与证据"
    return ""


def section_of(card: dict) -> str:
    explicit = text_of(card.get("档案栏目"))
    if explicit in SECTIONS:
        return explicit
    legacy = MARK_RE.search(text_of(card.get("备注")))
    if legacy and text_of(legacy.group(2)) in SECTIONS:
        return text_of(legacy.group(2))
    kind = text_of(card.get("材料类型"))
    name = text_of(card.get("材料名称"))
    fname = text_of(card.get("文件名"))
    sec = infer_section(kind) or infer_section(name)
    if not sec and re.search(r"\.(eml|msg)$", fname, re.I):
        sec = "沟通记录"
    return sec or infer_section(fname) or "文档与证据"


def scan_vault(vault: Path, only: str = "") -> tuple[list[dict], list[str]]:
    root = vault / "事务列表"
    if not root.is_dir():
        raise SystemExit("库里没有「事务列表」目录：%s" % root)
    projects, skipped = [], []
    for note in sorted(root.glob("*/事务.md")):
        meta = front_matter(note)
        oid = text_of(meta.get("事务ID"))
        name = text_of(meta.get("事务名称"))
        if not oid or not name:
            skipped.append("%s（缺事务ID或事务名称）" % note.parent.name)
            continue
        if only and only not in name and only not in note.parent.name:
            continue
        cards = []
        for card_path in sorted(note.parent.glob("文档与证据/*/材料卡.md")):
            card = front_matter(card_path)
            mid = text_of(card.get("材料ID")).lower()
            fname = text_of(card.get("文件名"))
            if not re.fullmatch(r"[0-9a-f]{64}", mid) or not fname:
                skipped.append("%s（材料卡缺材料ID或文件名）" % card_path.parent.name)
                continue
            location = text_of(card.get("存放位置"))
            if not location:
                origin = card_path.parent / "原件" / fname
                location = origin.relative_to(vault).as_posix()
            cards.append({
                "材料ID": mid,
                "文件名": fname,
                "材料名称": text_of(card.get("材料名称")),
                "材料类型": text_of(card.get("材料类型")) or "待确认",
                "档案栏目": section_of(card),
                "存放位置": location,
                "版本": text_of(card.get("版本")) or "v1",
                "提交状态": submit_state(card.get("是否提交法院")),
                "登记日期": text_of(card.get("登记日期"))[:10],
                "备注": MARK_RE.sub("", SUBMIT_RE.sub("", text_of(card.get("备注")))).strip(),
            })
        projects.append({"obsidianId": oid, "name": name, "folder": note.parent.name,
                         "note": note, "meta": meta, "materials": cards})
    return projects, skipped


# ---------------------------------------------------------------- 同步计划
def build_plan(projects, matters, docs, cfg_rows, vault_label):
    mapping = {}
    meta_row = None
    for r in cfg_rows:
        if text_of(r.get("类别")) != CFG_CAT:
            continue
        key = text_of(r.get("键名"))
        if key == CFG_META:
            meta_row = r
            continue
        try:
            value = json.loads(text_of(r.get("值")) or "{}")
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and value.get("matterId"):
            mapping[key] = value

    matter_ids = {m["record_id"]: m for m in matters}
    by_name = {}
    for m in matters:
        by_name.setdefault(text_of(m.get("事务名称")), []).append(m)
    docs_by_matter = {}
    for d in docs:
        docs_by_matter.setdefault(text_of(d.get("事务ID")), []).append(d)

    plan = {"reuse": [], "create": [], "pending": [], "materials": [], "mapping": []}
    for p in projects:
        key = "%s::%s" % (vault_label, p["obsidianId"])
        rec = mapping.get(key)
        if rec and rec.get("matterId") in matter_ids:
            plan["reuse"].append({"project": p, "record": matter_ids[rec["matterId"]], "key": key})
            continue
        same = by_name.get(p["name"]) or []
        if same:
            plan["pending"].append({"project": p, "reason": "库内已有同名事务但无来源映射，无法确认是否同一项目",
                                    "candidates": [{"record_id": m["record_id"], "名称": text_of(m.get("事务名称")),
                                                    "阶段": text_of(m.get("所处阶段"))} for m in same]})
            continue
        plan["create"].append({"project": p, "key": key})

    # 材料：以最终会写入的事务记录为准，按事务ID＋材料ID 去重
    bucket = [(x["project"], x["record"]) for x in plan["reuse"]]
    for x in plan["create"]:
        bucket.append((x["project"], None))
    for project, record in bucket:
        existing = docs_by_matter.get(record["record_id"], []) if record else []
        have = {}
        for d in existing:
            mid = text_of(d.get("材料ID")).lower()
            if not mid:
                legacy = MARK_RE.search(text_of(d.get("备注")))
                mid = legacy.group(1) if legacy else ""
            if mid:
                have[mid] = d
        for card in project["materials"]:
            if card["材料ID"] in have:
                continue
            plan["materials"].append({"project": project, "card": card})
    return plan, mapping, meta_row


def matter_payload(project) -> dict:
    meta = project["meta"]
    props = {
        "事务名称": {"text": project["name"]},
        "所处阶段": {"select": "已受理"},
        "事务类型": {"select": "其他"},
        "下一步行动": {"text": "补全事务信息与材料分类"},
        "卡点风险": {"text": ""},
        "是否卡住": {"checkbox": False},
        "是否涉密": {"checkbox": False},
        "创建日期": {"date": datetime.now().strftime("%Y-%m-%d")},
        "案号": {"text": text_of(meta.get("案号"))},
        "我方客户": {"text": text_of(meta.get("我方客户"))},
        "对方当事人": {"text": text_of(meta.get("对方当事人"))},
        "案件细分": {"text": text_of(meta.get("案件细分")) or text_of(meta.get("案由"))},
        "证据材料": {"text": ""},
    }
    return {k: v for k, v in props.items() if not (k in ("案号", "我方客户", "对方当事人", "案件细分") and v["text"] == "")}


def doc_payload(matter_id: str, card: dict) -> dict:
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    note = card["备注"]
    if card["提交状态"] == "待确认":
        note = (note + " 〔提交 待确认〕").strip() if note else "〔提交 待确认〕"
    return {
        "事务ID": {"text": matter_id},
        "文件名": {"text": card["文件名"]},
        "材料类型": {"text": card["材料类型"]},
        "存放位置": {"text": card["存放位置"]},
        "版本": {"text": card["版本"]},
        "是否提交法院": {"checkbox": card["提交状态"] == "已提交"},
        "登记日期": {"date": card["登记日期"] or datetime.now().strftime("%Y-%m-%d")},
        "材料ID": {"text": card["材料ID"]},
        "档案栏目": {"select": card["档案栏目"]},
        "备注": {"text": note},
        "更新时间": {"text": now},
    }


def upsert_mapping(rows, wanted: dict[str, dict]):
    """wanted: key -> {matterId, vault, obsidianId, name, folder, linkedAt}"""
    existing = {}
    for r in rows:
        if text_of(r.get("类别")) == CFG_CAT and text_of(r.get("键名")) != CFG_META:
            existing[text_of(r.get("键名"))] = r
    now = datetime.now().strftime("%Y-%m-%d %H:%M")
    adds, updates = [], []
    for key, value in wanted.items():
        body = json.dumps(value, ensure_ascii=False)
        if key in existing:
            if text_of(existing[key].get("值")) != body:
                updates.append({"record_id": existing[key]["record_id"],
                                "properties": {"值": {"text": body}, "更新日期": {"date": now[:10]},
                                               "更新时间": {"text": now}}})
        else:
            adds.append({"类别": {"text": CFG_CAT}, "键名": {"text": key}, "值": {"text": body},
                         "备注": {"text": "Obsidian 事务来源映射，不参与期限与字典运算"},
                         "更新日期": {"date": now[:10]}, "更新时间": {"text": now}})
    return adds, updates


def print_summary(result: dict) -> None:
    """给定时任务/人工看的中文摘要（JSON 仍是机器可读的主输出）。"""
    lines = ["", "== 同步摘要 =="]
    lines.append("扫描项目 %d 个、材料卡 %d 张；复用 %d、新建事务 %d、新增材料 %d"
                 % (result.get("projects", 0), result.get("materials", 0), result.get("reused", 0),
                    result.get("created", 0), result.get("created_materials", 0)))
    if result.get("lock_waited"):
        lines.append("本轮开始时检测到归档同步正在执行，已等它结束后再补扫。")
    pending_archive = result.get("pending_archive") or []
    if pending_archive:
        lines.append("待归档 %d 项（只有原件、缺索引，需人工补归档）：" % len(pending_archive))
        for item in pending_archive[:10]:
            lines.append("  · %s：%s（%d 个文件）" % (item["类型"], item["位置"], item["文件数"]))
            for f in (item.get("文件") or [])[:3]:
                lines.append("      - " + f)
    pending = result.get("pending") or []
    if pending:
        lines.append("待确认 %d 项（库内已有同名事务，无法判定是否同一项目）：" % len(pending))
        for item in pending[:10]:
            lines.append("  · %s（%s）" % (item["project"]["name"], item["reason"]))
    if result.get("skipped"):
        lines.append("跳过 %d 项（缺材料ID/文件名或事务ID）：%s"
                     % (len(result["skipped"]), "；".join(result["skipped"][:5])))
    errors = result.get("errors") or []
    if errors:
        lines.append("写入失败 %d 条 → 已归档，待同步；下次运行会继续补齐：" % len(errors))
        for e in errors[:5]:
            lines.append("  · " + str(e))
    print("\n".join(lines))


# ---------------------------------------------------------------- 主流程
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vault", default=DEFAULT_VAULT)
    ap.add_argument("--only", default="", help="只同步名称/目录名包含该字符串的项目")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--json", default="", help="把结果另存为 JSON")
    ap.add_argument("--library", default="", help="资料库技能目录")
    ap.add_argument("--lock-timeout", type=int, default=600,
                    help="归档同步正在执行时最多等待秒数（默认 600；0 表示不等待，直接跳过本轮）")
    args = ap.parse_args()
    if not all((MATTERS_DB, DOCS_DB, CFG_DB)):
        raise SystemExit("请先把本工作台绑定的 事务、文档与证据、配置与规则 三个表 ID 填入脚本顶部。")
    if args.library:
        os.environ["CODEBUDDY_SKILL_DIR"] = args.library

    vault = Path(args.vault).expanduser()
    if not vault.is_dir():
        raise SystemExit("库目录不存在：%s" % vault)
    vault_label = vault.name

    # 与归档流程共用一把锁：正在归档就等它结束，避免同一事务被重复写入
    lock, waited = acquire_lock(vault, args.lock_timeout)
    if lock is None:
        print(json.dumps({
            "status": "busy", "vault": vault_label,
            "message": "归档同步正在进行，已等待 %d 秒仍未结束，本轮跳过；下次运行会继续补齐。" % args.lock_timeout,
        }, ensure_ascii=False, indent=1))
        return 2
    atexit.register(lambda: lock.unlink(missing_ok=True))

    pending_archive = scan_pending(vault, args.only)

    try:
        matters = query_all(MATTERS_DB)
        docs = query_all(DOCS_DB)
        cfg_rows = query_all(CFG_DB)
    except Exception as exc:  # 离线或服务不可达：本轮不改动任何数据
        print(json.dumps({
            "status": "unreachable", "vault": vault_label,
            "message": "本次连不上在线表，未做任何改动；下次运行会继续补齐。",
            "errors": [str(exc)], "pending_archive": pending_archive,
        }, ensure_ascii=False, indent=1))
        return 1

    projects, skipped = scan_vault(vault, args.only)
    plan, mapping, meta_row = build_plan(projects, matters, docs, cfg_rows, vault_label)

    result = {
        "vault": vault_label,
        "projects": len(projects),
        "materials": sum(len(p["materials"]) for p in projects),
        "reused": len(plan["reuse"]),
        "created": 0,
        "created_materials": 0,
        "pending": plan["pending"],
        "pending_archive": pending_archive,
        "pending_archive_count": len(pending_archive),
        "lock_waited": waited,
        "skipped": skipped,
        "notes": [],
        "errors": [],
        "dry_run": args.dry_run,
    }
    for x in plan["reuse"]:
        if text_of(x["record"].get("事务名称")) != x["project"]["name"]:
            result["notes"].append("名称不一致（保留工作台现有名称）：库内「%s」/ 工作台「%s」"
                                   % (x["project"]["name"], text_of(x["record"].get("事务名称"))))

    if args.dry_run:
        result["will_create"] = len(plan["create"])
        result["will_add_materials"] = len(plan["materials"])
        result["will_link_existing"] = len(plan["reuse"])
        print(json.dumps(result, ensure_ascii=False, indent=1))
        print_summary(result)
        return 0

    touched: dict[str, dict] = {}
    matter_id_by_key: dict[str, str] = {}

    # 1) 新建事务
    if plan["create"]:
        payloads = [matter_payload(x["project"]) for x in plan["create"]]
        try:
            ids = add_records(MATTERS_DB, payloads)
        except RuntimeError as exc:
            result["errors"].append(str(exc))
            ids = []
        for x, mid in zip(plan["create"], ids):
            if not mid:
                result["errors"].append("新建事务失败：%s" % x["project"]["name"])
                continue
            result["created"] += 1
            matter_id_by_key[x["key"]] = mid
            touched[x["key"]] = {"matterId": mid, "vault": vault_label, "obsidianId": x["project"]["obsidianId"],
                                 "name": x["project"]["name"], "folder": x["project"]["folder"],
                                 "linkedAt": datetime.now().strftime("%Y-%m-%d %H:%M")}
    for x in plan["reuse"]:
        matter_id_by_key[x["key"]] = x["record"]["record_id"]
        touched[x["key"]] = {"matterId": x["record"]["record_id"], "vault": vault_label,
                             "obsidianId": x["project"]["obsidianId"], "name": x["project"]["name"],
                             "folder": x["project"]["folder"], "linkedAt": datetime.now().strftime("%Y-%m-%d %H:%M")}

    # 2) 写材料（按事务分组）
    by_project: dict[str, list] = {}
    for item in plan["materials"]:
        by_project.setdefault(item["project"]["obsidianId"], []).append(item["card"])
    for project in projects:
        cards = by_project.get(project["obsidianId"]) or []
        if not cards:
            continue
        key = "%s::%s" % (vault_label, project["obsidianId"])
        mid = matter_id_by_key.get(key)
        if not mid:
            continue
        try:
            ids = add_records(DOCS_DB, [doc_payload(mid, c) for c in cards])
            added = sum(1 for i in ids if i)
            result["created_materials"] += added
            if added != len(cards):
                result["errors"].append("材料写入不完整：%s（%d/%d）" % (project["name"], added, len(cards)))
        except RuntimeError as exc:
            result["errors"].append("材料写入失败：%s（%s）" % (project["name"], exc))

    # 3) 来源映射与导入状态
    try:
        adds, updates = upsert_mapping(cfg_rows, touched)
        if adds:
            add_records(CFG_DB, adds)
        if updates:
            update_records(CFG_DB, updates)
        meta_value = {"vault": vault_label,
                      "lastImportAt": datetime.now().strftime("%Y-%m-%d %H:%M"),
                      "source": "sync_workbench.py"}
        body = json.dumps(meta_value, ensure_ascii=False)
        if meta_row:
            update_records(CFG_DB, [{"record_id": meta_row["record_id"],
                                     "properties": {"值": {"text": body},
                                                    "更新日期": {"date": datetime.now().strftime("%Y-%m-%d")},
                                                    "更新时间": {"text": datetime.now().strftime("%Y-%m-%d %H:%M")}}}])
        else:
            add_records(CFG_DB, [{"类别": {"text": CFG_CAT}, "键名": {"text": CFG_META}, "值": {"text": body},
                                  "备注": {"text": "Obsidian 清单导入状态，不参与期限与字典运算"},
                                  "更新日期": {"date": datetime.now().strftime("%Y-%m-%d")},
                                  "更新时间": {"text": datetime.now().strftime("%Y-%m-%d %H:%M")}}])
    except RuntimeError as exc:
        result["errors"].append("来源映射写入失败：%s" % exc)

    print(json.dumps(result, ensure_ascii=False, indent=1))
    if args.json:
        Path(args.json).write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print_summary(result)
    return 1 if result["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())

"""Local case archive helper. Python 3.10+ and PyYAML 6."""
import argparse
from contextlib import contextmanager
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile
from urllib.parse import quote, unquote
from uuid import uuid4, uuid5, NAMESPACE_URL
import yaml


def require(condition, message):
    if not condition:
        raise ValueError(message)


def canonical(path):
    return Path(path).expanduser().resolve(strict=True)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def inventory(inputs):
    files, skipped = {}, []
    def visit(p):
        if p.is_symlink() or p.resolve() != p.absolute():
            skipped.append(str(p))
        elif p.is_dir():
            if p.name in {'.obsidian', '.git', '.trash'}:
                skipped.append(str(p))
            else:
                for child in sorted(p.iterdir()):
                    visit(child)
        elif p.is_file() and not (p.name.startswith('~$') or p.name in {'Thumbs.db','.DS_Store','desktop.ini'}):
            if str(p) not in files:
                files[str(p)] = digest(p)
        else:
            skipped.append(str(p))
    for value in inputs:
        p = Path(value).expanduser().absolute()
        require(p.exists(), f'找不到输入：{p}')
        visit(p)
    return {'files': [{'path': p, 'sha256': h} for p,h in files.items()], 'skipped': skipped}


def clean(text, limit):
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', text).strip()[:limit].rstrip(' .')
    require(name and name not in {'.','..'}, '需要可读的名称')
    if re.match(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)', name, re.I):
        name = '_'+name
    return name


def inside(path, parent):
    require(path.resolve() == path and path.is_relative_to(parent), f'路径超出归档范围或含链接：{path}')
    return path


def read_note(path):
    raw = path.read_bytes()
    text = raw.decode('utf-8-sig')
    m = re.match(r'^---\r?\n(.*?)^---[ \t]*(?:\r?\n|$)', text, re.S|re.M)
    require(m, f'笔记缺少 YAML 属性：{path}')
    fields = yaml.safe_load(m[1])
    require(isinstance(fields,dict), f'笔记属性无效：{path}')
    return raw, fields, text, m


def emit(fields, body):
    header = ''.join(k+': '+json.dumps(v,ensure_ascii=False)+'\n' for k,v in fields.items())
    return ('---\n'+header+'---\n\n'+body+'\n').encode('utf-8')


def with_sources(note, paths):
    raw, fields, text, match = note
    old = fields.get('收件来源') or []
    if isinstance(old,str):
        old = [old]
    require(isinstance(old,list) and all(isinstance(x,str) for x in old),'已有收件来源格式异常')
    merged = list(dict.fromkeys([*old,*paths]))
    if merged == old:
        return raw
    # Touch only this YAML value. Preserve manual remarks, comments and the note body.
    hdr = match[1]
    value = json.dumps(merged,ensure_ascii=False)
    node = next((v for k,v in yaml.compose(hdr).value if k.value=='收件来源'),None)
    nl = '\r\n' if '\r\n' in hdr else '\n'
    if node:
        a,b = node.start_mark.index,node.end_mark.index
        sep = nl if b>a and hdr[a:b].endswith('\n') else ''
        if '\n' in hdr[:a].rsplit('收件来源',1)[-1] and node.start_mark.column == 0:
            value = '  '+value
        hdr = hdr[:a]+value+sep+hdr[b:]
    else:
        hdr += '收件来源: '+value+nl
    require(yaml.safe_load(hdr)=={**fields,'收件来源':merged},'来源更新与笔记原有属性冲突')
    out = text[:match.start(1)]+hdr+text[match.end(1):]
    return out.encode('utf-8-sig' if raw.startswith(b'\xef\xbb\xbf') else 'utf-8')


@contextmanager
def vault_lock(vault):
    key = hashlib.sha256(os.path.normcase(str(vault)).encode()).hexdigest()
    with (Path(tempfile.gettempdir())/('obsidian-case-'+key+'.lock')).open('a+b') as f:
        f.seek(0)
        if os.name == 'nt':
            import msvcrt
            msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
        yield


def replace_if_unchanged(file, before, after, scratch):
    if after == before:
        return
    tmp = scratch/uuid4().hex
    tmp.write_bytes(after)
    require(file.read_bytes()==before, f'文件已被其他程序修改，请重新读取：{file}')
    os.replace(tmp,file)


def find_project(root, name, requested):
    hits = []
    for p in root.glob('*/事务.md'):
        fields=read_note(inside(p,root))[1]
        if (fields.get('事务ID')==requested if requested else fields.get('事务名称')==name):
            hits.append((fields['事务ID'],p.parent))
    require(len(hits)<=1,'匹配到多个事务，请核对事务 ID')
    if hits:
        key,folder=hits[0]
    else:
        key=requested or 'case-'+uuid5(NAMESPACE_URL,name).hex
        suffix=hashlib.sha256(key.encode()).hexdigest()[:24]
        folder=root/(clean(name,45)+' · '+suffix)
        require(not folder.exists(),f'目标目录已存在，请核对：{folder}')
    require(isinstance(key,str) and re.fullmatch(r'[A-Za-z0-9_-]{1,150}',key),'事务 ID 不符合工作台格式')
    return key,folder


def apply(vault, plan, write):
    name=plan['case_name'].strip()
    require(name and plan['items'],'需要事务名和至少一项材料')
    root=inside(vault/'事务列表',vault)
    with vault_lock(vault), tempfile.TemporaryDirectory(prefix='.case-archive-',dir=vault) as tmp:
        scratch=Path(tmp)
        key,case=find_project(root,name,plan.get('case_id'))
        fresh=not case.exists()
        project=scratch/'project' if fresh else case
        docs=inside(project/'文档与证据',project)
        existing={}
        for p in docs.glob('*/材料卡.md'):
            note=read_note(inside(p,docs))
            h=note[1].get('材料ID')
            require(note[1].get('事务ID')==key and isinstance(h,str) and re.fullmatch('[a-f0-9]{64}',h) and h not in existing,f'材料标识冲突：{p}')
            existing[h]=(p,note)
        items={}
        for item in plan['items']:
            h=item['sha256']
            require(item.get('sources') and isinstance(item['sources'],list),'缺少来源文件列表')
            for value in item['sources']:
                p=canonical(value)
                require(p.is_file() and digest(p)==h,f'文件或哈希已变化：{p}')
                paths=items.setdefault(h,(item,[]))[1]
                if p not in paths: paths.append(p)
        now=datetime.now().astimezone()
        used={p.name.casefold() for p in docs.iterdir()} if docs.exists() else set()
        seq=max((int(m[1]) for n in used if (m:=re.match(r'^(\d+)_',n))),default=0)
        cards,updates,newdirs,rows=[],[],[],[]
        for h,(item,sources) in items.items():
            paths=[str(p) for p in sources]
            if h in existing:
                card,note=existing[h]
                old=note[1]
                original=inside(vault/old['存放位置'],card.parent)
                require(original.is_file() and digest(original)==h,f'既有归档原件与材料 ID 不符：{card}')
                after=with_sources(note,paths)
                updates.append((card,note[0],after))
                title=old.get('材料名称') or old['文件名']
                folder=card.parent.name
                status='追加来源' if after!=note[0] else '已归档'
            else:
                title=item['title'].strip()
                base=clean(title,60)
                while True:
                    seq+=1
                    folder=f'{seq:02d}_{base}'
                    if folder.casefold() not in used:break
                used.add(folder.casefold())
                stage=(docs if fresh else scratch/'materials')/folder
                (stage/'原件').mkdir(parents=True)
                p=sources[0]
                copied=stage/'原件'/p.name
                shutil.copy2(p,copied)
                require(digest(copied)==h,f'复制校验失败：{p}')
                rel=(case/'文档与证据'/folder/'原件'/p.name).relative_to(vault).as_posix()
                fields=dict(事务ID=key,材料ID=h,文件名=p.name,材料名称=title,材料类型=item.get('kind') or '待确认',存放位置=rel,
                            版本=item.get('version') or 'v1',是否提交法院='待确认',登记日期=now.date().isoformat(),
                            备注=item.get('summary',''),更新时间=now.isoformat(timespec='seconds'),收件来源=paths)
                body='# '+title+'\n\n'+fields['备注']+'\n\n[打开归档原件](原件/'+quote(p.name)+')'
                (stage/'材料卡.md').write_bytes(emit(fields,body))
                if not fresh:newdirs.append((stage,docs/folder))
                status='新增'
            link='文档与证据/'+folder+'/材料卡.md'
            label=title.replace('[','［').replace(']','］').replace('\n',' ')
            rows.append((link,'- ['+label+']('+quote(link,safe='/')+')'))
            cards.append(dict(材料=title,结果=status,材料卡=link,材料ID=h))
        index=project/'事务.md'
        if fresh:
            fields={'事务ID':key,'事务名称':name}
            for k,v in plan.get('properties',{}).items():
                require(k not in fields and re.fullmatch(r'[\w -]+',k),'事务属性名无效或重复')
                fields[k]=v
            index.write_bytes(emit(fields,'# '+name+'\n\n## 材料清单\n\n'+'\n'.join(r for _,r in rows)))
        else:
            before=index.read_bytes()
            decoded=unquote(before.decode('utf-8-sig'))
            missing=[r for link,r in rows if link not in decoded]
            if missing:
                nl=b'\r\n' if b'\r\n' in before else b'\n'
                addition=nl.join(s.encode() for s in missing)
                updates.append((index,before,before+nl+nl+b'## '+ '补充材料'.encode()+nl+nl+addition+nl))
        if write:
            if fresh:
                root.mkdir(exist_ok=True)
                require(not case.exists(),'事务已同时创建，请重试')
                project.rename(case)
            else:
                if newdirs:docs.mkdir(exist_ok=True)
                for stage,target in newdirs:
                    require(not target.exists(),f'材料目录已被占用：{target}')
                    stage.rename(target)
                for file,before,after in updates:replace_if_unchanged(file,before,after,scratch)
            for row in cards:
                card=inside(case/row['材料卡'],case)
                fields=read_note(card)[1]
                require(fields['事务ID']==key and fields['材料ID']==row['材料ID'] and
                        digest(inside(vault/fields['存放位置'],card.parent))==row['材料ID'],f'归档复核失败：{card}')
        return dict(已写入=write,事务ID=key,事务目录=str(case),材料=cards)


def main():
    parser=argparse.ArgumentParser()
    subs=parser.add_subparsers(dest='command',required=True)
    subs.add_parser('inventory').add_argument('inputs',nargs='+')
    archive=subs.add_parser('archive')
    archive.add_argument('--vault',required=True)
    archive.add_argument('--plan',required=True)
    archive.add_argument('--write',action='store_true')
    args=parser.parse_args()
    if args.command=='inventory':
        result=inventory(args.inputs)
    else:
        result=apply(canonical(args.vault),json.loads(Path(args.plan).read_text('utf-8-sig')),args.write)
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':
    try:main()
    except (OSError,ValueError,KeyError,TypeError,yaml.YAMLError) as exc:
        sys.exit('归档操作未完成：'+str(exc))
